<?php

namespace Gondr\Controller;

class ProductController extends MasterController
{
    public function index()
    {
        $this->render("product/index");
    }

}