<div class="container">
    <div class="row mt-5">
        <div class="col-10 offset-1" id="content">
            <div class="jumbotron jumbotron-fluid">
                <div class="container">
                    <h1 class="display-4">Skill 2025 Sample page</h1>
                    <p class="lead">2025 기능대회용 샘플 페이지</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-3" >
        <div class="col-12">

        </div>
    </div>
    <!-- INSERT INTO todos(title, content,owner, date) ( SELECT title, content, owner, date FROM todos ) -->

</div>
<div id="loadingbox" class="df-center">
    <h2><i class="fas fa-spinner fa-spin"></i></h2>
</div>

<script src="/js/MainApp.js"></script>