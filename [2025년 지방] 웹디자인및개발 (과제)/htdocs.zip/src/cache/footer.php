    <footer class="row bg-dark text-white d-flex justify-content-center align-items-center">
        <div class="col-12 text-center">
            <p class="m-0">&copy; Copyright 2020. all rights reseved to YYDH </p>
        </div>
    </footer>
</div>
</body>
</html>